﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleGameApp
{
    internal class GameInit
    {
        internal void Init()
        {
            //Welcome Screen
            #region WelcomeScreen
            Console.WriteLine(" ________  ___  ___  ________   ________  _______   ________  ________           ________  ___  ___  ________  ___  ___     \r\n|\\   ___ \\|\\  \\|\\  \\|\\   ___  \\|\\   ____\\|\\  ___ \\ |\\   __  \\|\\   ___  \\        |\\   __  \\|\\  \\|\\  \\|\\   ____\\|\\  \\|\\  \\    \r\n\\ \\  \\_|\\ \\ \\  \\\\\\  \\ \\  \\\\ \\  \\ \\  \\___|\\ \\   __/|\\ \\  \\|\\  \\ \\  \\\\ \\  \\       \\ \\  \\|\\  \\ \\  \\\\\\  \\ \\  \\___|\\ \\  \\\\\\  \\   \r\n \\ \\  \\ \\\\ \\ \\  \\\\\\  \\ \\  \\\\ \\  \\ \\  \\  __\\ \\  \\_|/_\\ \\  \\\\\\  \\ \\  \\\\ \\  \\       \\ \\   _  _\\ \\  \\\\\\  \\ \\_____  \\ \\   __  \\  \r\n  \\ \\  \\_\\\\ \\ \\  \\\\\\  \\ \\  \\\\ \\  \\ \\  \\|\\  \\ \\  \\_|\\ \\ \\  \\\\\\  \\ \\  \\\\ \\  \\       \\ \\  \\\\  \\\\ \\  \\\\\\  \\|____|\\  \\ \\  \\ \\  \\ \r\n   \\ \\_______\\ \\_______\\ \\__\\\\ \\__\\ \\_______\\ \\_______\\ \\_______\\ \\__\\\\ \\__\\       \\ \\__\\\\ _\\\\ \\_______\\____\\_\\  \\ \\__\\ \\__\\\r\n    \\|_______|\\|_______|\\|__| \\|__|\\|_______|\\|_______|\\|_______|\\|__| \\|__|        \\|__|\\|__|\\|_______|\\_________\\|__|\\|__|\r\n                                                                                                       \\|_________|         \r\n                                                                                                                            \r\n                                                                                                                            ");
            Console.WriteLine("Hello. Welcome to Dungeon Rush.");
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
            #endregion
            //Player Initialization
            #region PlayerInit
            Console.WriteLine("What would you like to be called?[Enter For Default] ");
            string username = Console.ReadLine()!;
            Console.WriteLine("Please provide one of the valid classes(Warrior,Mage,Archer)[Enter For Default]: ");
            string playerClass = Console.ReadLine()!;

            PlayerData player = new PlayerData(username, playerClass);
            Console.WriteLine(player.PlayerInfo());
            #endregion
            //Subfunctions
            #region Subfunctions
            MapInit();
            void Exit()
            {
                Console.Clear();
                Console.WriteLine("Are you sure you want to exit?(Yes)[Enter For No]");
                string confirm = Console.ReadLine()!;
                if (confirm.ToLower() == "yes")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.Clear();
                    MapInit();
                }
            }
            void MapInit()
            {
                MapGeneration mapGeneration = new MapGeneration();
                Console.WriteLine("Map Preview:");
                mapGeneration.PrintDefaultMap();
                Console.WriteLine("Regenerate Map, Exit Game, Ready(Exit,Ready)[Enter For Map Reroll]");
                string answer = Console.ReadLine()!;
                if (answer.ToLower() == "ready")
                {
                    Console.Clear();
                    Console.WriteLine(player.PlayerInfo());
                    Console.WriteLine("Your Map:");
                    mapGeneration.PrintChangedMap();

                } else if (answer.ToLower() == "exit") {
                    Exit();
                } else
                {
                    Console.Clear();
                    Console.WriteLine(player.PlayerInfo());
                    MapInit();
                }
            }
            void Death()
            {
                Console.Clear();
                Console.WriteLine("You have died.");
                Console.WriteLine("Restart or Exit?");
                string confirm = Console.ReadLine()!;
                if (confirm.ToLower() == "yes")
                {
                    Exit();
                }
                else
                {
                    Init();
                }
            }
            void Fight(string Attacker, int Health, string Weapon)
            {
                switch (Attacker)
                {
                    case "Boss":

                        break;
                    case "Mob":

                        break;
                }
                int HealthFight = Health;
                switch (Weapon)
                {
                    case "Boss":

                        break;
                    case "Mob":

                        break;
                }
            }
            #endregion
        }
    }
}
