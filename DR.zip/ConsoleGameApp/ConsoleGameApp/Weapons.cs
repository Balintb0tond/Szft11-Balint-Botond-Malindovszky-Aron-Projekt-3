﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonRush
{
    internal class Weapons
    {
        public void QuickBlade()
        {
            int Damage = 90;
            string Skill = "QuickBladeSkill";
        }
        public void OversizedSword()
        {
            int Damage = 200;
        }
        public void Longbow()
        {
            int Damage = 150;
            string Skill = "LongbowSkill";
        }
        public void Swiftbow()
        {
            int Damage = 110;
            string Skill = "SwiftbowSkill";
        }
        public void AncientBook()
        {
            int Damage = 130;
            string Skill = "AncientBookSkill";
        }
        public void BookOfDemise()
        {
            int Damage = 110;
            string Skill = "BookOfDemiseSkill";
        }
        public void DemonicBlade()
        {
            int Damage = 130;
            string Skill = "DemonicBladeSkill";
        }
        public void DemonicBow()
        {
            int Damage = 160;
            string Skill = "DemonicBowSkill";
        }
        public void DemonicBook()
        {
            int Damage = 185;
            string Skill = "DemonicBookSkill";
        }
    }
}
