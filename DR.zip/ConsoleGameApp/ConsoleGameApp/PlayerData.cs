﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleGameApp
{
    internal class PlayerData
    {
		private string classname;

		public string Classname
		{
			get { return classname; }
			set 
			{
				if (value == "Warrior" || value == "Mage" || value == "Archer")
				{
					classname = value;
				} else
				{
					classname = "Warrior";
				}
			}
		}
		public string PlayerName { get; set; }


		public string PlayerInfo()
		{
			return $"-- Current Player Profile --\nPlayer Name: {PlayerName}\nPlayer Class: {Classname}";
		}
		public PlayerData(string Username,string Class)
		{
			PlayerName = Username;
			Classname = Class;
		}

    }
}
