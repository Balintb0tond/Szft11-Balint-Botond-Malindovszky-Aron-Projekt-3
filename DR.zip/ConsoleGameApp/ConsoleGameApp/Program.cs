﻿using ConsoleGameApp;

GameInit game = new GameInit();
game.Init();