﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleGameApp
{
    internal class MapGeneration
    {
        #region CharSettings
        private char[] characterSet = { '_', '_', '_', '_', '~', '^', '^', '=' }; //Allowed Characters ["_" used for wider variety]
        private Random random = new Random();
        #endregion
        #region SizeSettings
        private int mapRows = 50; //Max Map Length
        private int mapColumns = 50; //Max Map Width
        private char[,] map;
        #endregion
        #region MapGen, Def/Altered Print
        public MapGeneration()
        {
            map = GenerateRandomMap(); //Generating Map
        }

        public void PrintDefaultMap() //Printing Default Map
        {
            PrintMap(map);
        }

        public void PrintChangedMap() //Printing Altered Map
        {
            char[,] changedMap = (char[,])map.Clone();

            PlaceRandomCharacters(changedMap); // Applying Changes

            PrintMap(changedMap);
        }
        #endregion

        private char[,] GenerateRandomMap()
        {
            char[,] map = new char[mapRows, mapColumns];

            for (int i = 0; i < mapRows; i++)
            {
                for (int j = 0; j < mapColumns; j++)
                {
                    if (i == 0 || i == mapRows - 1 || j == 0 || j == mapColumns - 1)
                    {
                        map[i, j] = '#'; // Border
                    }
                    else
                    {
                        int index = random.Next(characterSet.Length);
                        map[i, j] = characterSet[index];
                    }
                }
            }

            return map;
        }

        private void PlaceRandomCharacters(char[,] map)
        {
            int maxBCount = 20; // Maximum number of Bosses
            int maxMCount = 150; // Maximum number of Monsters
            int maxCCount = 1; // Maximum number of Player Characters

            int bCount = 0;
            int mCount = 0;
            int cCount = 0;

            while (bCount < maxBCount || mCount < maxMCount || cCount < maxCCount)
            {
                int randomRow = random.Next(0, mapRows);
                int randomCol = random.Next(0, mapColumns);

                if (map[randomRow, randomCol] != '#') // Border Check
                {
                    int randomValue = random.Next(1, 101);

                    if (randomValue <= 10 && bCount < maxBCount) // 10% chance for Bosses
                    {
                        map[randomRow, randomCol] = 'B';
                        bCount++;
                    }
                    else if (randomValue <= 30 && mCount < maxMCount) // 20% chance for Monsters
                    {
                        map[randomRow, randomCol] = 'M';
                        mCount++;
                    }
                    else if (randomValue <= 60 && cCount < maxCCount) // 30% chance for Player Character
                    {
                        map[randomRow, randomCol] = 'C';
                        cCount++;
                    }
                }
            }
        }

        private void PrintMap(char[,] map)
        {
            for (int i = 0; i < mapRows; i++)
            {
                for (int j = 0; j < mapColumns; j++)
                {
                    if (map[i, j] == 'C')
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                    }
                    else if (map[i, j] == 'B')
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else if (map[i, j] == 'M')
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    }
                    Console.Write(map[i, j]);
                    Console.ResetColor();
                    Console.Write(" ");

                }
                Console.WriteLine();
            }
        }
    }
}